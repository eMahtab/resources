# News Search Application

## Overview

The News Search application allows users to search for news articles by keyword, aggregating results from The Guardian and The New York Times. The application supports offline mode and pagination, ensuring a seamless experience even when the external news APIs are unavailable.

## Features

- **Search News:** Users can enter a keyword to search for relevant news articles.
- **Source Aggregation:** Fetches and merges news articles from The Guardian and The New York Times, eliminating duplicates.
- **Pagination Support:** Users can browse through multiple pages of results.
- **Offline Mode:** When enabled, the application serves cached results instead of fetching data from APIs.
- **User-friendly Interface:** A simple web page using HTML, JavaScript, and Bootstrap for an intuitive experience.

## APIs Used

### The Guardian API

- **Base URL:** `https://content.guardianapis.com/search`
- **Parameters:**
    - `q`: Keyword to search for articles.
    - `api-key`: Required authentication key.
- **Example Request:**
  ```
  https://content.guardianapis.com/search?q=apple&api-key=your-guardian-api-key
  ```

### New York Times API

- **Base URL:** `https://api.nytimes.com/svc/search/v2/articlesearch.json`
- **Parameters:**
    - `q`: Keyword to search for articles.
    - `api-key`: Required authentication key.
- **Example Request:**
  ```
  https://api.nytimes.com/svc/search/v2/articlesearch.json?q=apple&api-key=your-nyt-api-key
  ```

## Setup & Deployment

### Backend (Spring Boot Application)

1. Clone the repository.
2. Add your API keys in the application properties file.
3. Run the Spring Boot application:
   ```
   mvn spring-boot:run
   ```
4. The API will be available at `http://localhost:8080/news`.

### Frontend (HTML & JavaScript)

1. Open `index.html` in a web browser.
2. Enter a keyword and click "Search" to retrieve news articles.
3. Use the toggle switch to enable/disable offline mode.

## API Endpoints

| Method | Endpoint            | Description                                                 |
| ------ | ------------------- | ----------------------------------------------------------- |
| GET    | `/news?keyword={q}` | Fetches news articles by keyword.                           |
| POST   | `/news/offline`     | Toggles offline mode (expects `{ "offline": true/false }`). |

## Usage

1. Enter a search keyword (e.g., `Apple`).
2. Click "Search" to retrieve news articles.
3. Click article links to read full stories.
4. Toggle offline mode to use cached results when API is unavailable.

## Dependencies

- **Backend:** Java Spring Boot, REST APIs
- **Frontend:** HTML, JavaScript, Bootstrap

## Future Enhancements

- Add support for more news sources.
- Implement advanced filtering options.
- Enhance offline mode with local storage caching.


