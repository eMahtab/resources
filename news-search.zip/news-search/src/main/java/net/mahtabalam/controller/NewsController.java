package net.mahtabalam.controller;

import net.mahtabalam.model.NewsArticle;
import net.mahtabalam.service.NewsService;
import net.mahtabalam.util.OfflineCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/news")
public class NewsController {

    @Autowired
    private NewsService newsService;

    @GetMapping
    public ResponseEntity<List<NewsArticle>> searchNews(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int pageSize) {
        return ResponseEntity.ok(newsService.searchNews(keyword, page, pageSize));
    }

    @PostMapping("/offline")
    public ResponseEntity<String> toggleOffline(@RequestBody Map<String, Boolean> request) {
        boolean offline = request.getOrDefault("offline", false);
        OfflineCache.setOfflineMode(offline);
        return ResponseEntity.ok("Offline mode set to: " + offline);
    }
}
