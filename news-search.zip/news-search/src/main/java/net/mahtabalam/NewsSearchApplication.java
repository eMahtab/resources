package net.mahtabalam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsSearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewsSearchApplication.class, args);
	}

}
