package net.mahtabalam.service;

import net.mahtabalam.model.NewsArticle;
import net.mahtabalam.util.OfflineCache;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class NewsService {

    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${guardian.api.key}")
    private String guardianApiKey;

    @Value("${nyt.api.key}")
    private String nytApiKey;

    private static final String GUARDIAN_API_URL = "https://content.guardianapis.com/search?q=%s&api-key=%s";
    private static final String NYT_API_URL = "https://api.nytimes.com/svc/search/v2/articlesearch.json?q=%s&api-key=%s";

    public List<NewsArticle> searchNews(String keyword, int page, int pageSize) {
        if (OfflineCache.isOfflineMode()) {
            return getOfflineResults(keyword, page, pageSize);
        }

        List<NewsArticle> guardianResults = fetchGuardianNews(keyword);
        List<NewsArticle> nytResults = fetchNYTNews(keyword);

        List<NewsArticle> combined = mergeAndDeduplicate(guardianResults, nytResults);

        OfflineCache.cacheResults(keyword, combined);

        return paginateResults(combined, page, pageSize);
    }

    private List<NewsArticle> fetchGuardianNews(String keyword) {
        String url = String.format(GUARDIAN_API_URL, keyword, guardianApiKey);
        Map response = restTemplate.getForObject(url, Map.class);

        List<Map> results = (List<Map>) ((Map) response.get("response")).get("results");

        return results.stream()
                .map(r -> new NewsArticle(
                        (String) r.get("webTitle"),
                        (String) r.get("webUrl"),
                        "The Guardian"))
                .collect(Collectors.toList());
    }

    private List<NewsArticle> fetchNYTNews(String keyword) {
        String url = String.format(NYT_API_URL, keyword, nytApiKey);
        Map response = restTemplate.getForObject(url, Map.class);

        List<Map> results = (List<Map>) ((Map) response.get("response")).get("docs");

        return results.stream()
                .map(r -> new NewsArticle(
                        (String) r.get("abstract"),
                        (String) r.get("web_url"),
                        "New York Times"))
                .collect(Collectors.toList());
    }

    private List<NewsArticle> mergeAndDeduplicate(List<NewsArticle> list1, List<NewsArticle> list2) {
        Set<NewsArticle> resultSet = new HashSet<>();
        resultSet.addAll(list1);
        resultSet.addAll(list2);
        return new ArrayList<>(resultSet);
    }

    public List<NewsArticle> paginateResults(List<NewsArticle> results, int page, int pageSize) {
        int start = (page - 1) * pageSize;
        int end = Math.min(start + pageSize, results.size());
        return results.subList(start, end);
    }

    private List<NewsArticle> getOfflineResults(String keyword, int page, int pageSize) {
        List<NewsArticle> cachedResults = OfflineCache.getCachedResults(keyword);
        return paginateResults(cachedResults == null ? new ArrayList<>() : cachedResults, page, pageSize);
    }
}
