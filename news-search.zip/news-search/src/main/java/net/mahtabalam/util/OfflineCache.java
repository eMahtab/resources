package net.mahtabalam.util;

import net.mahtabalam.model.NewsArticle;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OfflineCache {
    private static final Map<String, List<NewsArticle>> cache = new HashMap<>();
    private static boolean offlineMode = false;

    public static boolean isOfflineMode() {
        return offlineMode;
    }

    public static void setOfflineMode(boolean mode) {
        offlineMode = mode;
    }

    public static void cacheResults(String keyword, List<NewsArticle> results) {
        cache.put(keyword, results);
    }

    public static List<NewsArticle> getCachedResults(String keyword) {
        return cache.get(keyword);
    }
}
