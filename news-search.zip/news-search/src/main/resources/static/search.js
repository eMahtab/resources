let currentPage = 1;
const pageSize = 8;
let currentKeyword = "";

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("pagination-controls").style.display = "none";
});

async function fetchNews(page = 1) {
    let keyword = document.getElementById("keyword").value.trim();
    if (!keyword) return;

    currentKeyword = keyword;
    currentPage = page;

    let newsContainer = document.getElementById("news-container");
    let paginationControls = document.getElementById("pagination-controls");
    newsContainer.innerHTML = "Loading...";

    try {
        let response = await fetch(`http://localhost:8080/news?keyword=${keyword}&page=${page}`);
        let data = await response.json();
        newsContainer.innerHTML = "";

        if (data.length === 0) {
            newsContainer.innerHTML = "<p class='text-center'>No news found.</p>";
            paginationControls.style.display = "none";
            return;
        }

        data.forEach(article => {
            let articleCard = `<div class='card mb-3'>
                <div class='card-body'>
                    <h5 class='card-title'>${article.title}</h5>
                    <p class='card-text'><strong>Source:</strong> ${article.source}</p>
                    <a href='${article.url}' target='_blank' class='btn btn-primary'>Read More</a>
                </div>
            </div>`;
            newsContainer.innerHTML += articleCard;
        });

        paginationControls.style.display = "flex";
        updatePaginationControls();
    } catch (error) {
        console.error("Error fetching news:", error);
        newsContainer.innerHTML = "<p class='text-danger'>Error loading news.</p>";
        paginationControls.style.display = "none";
    }
}

function updatePaginationControls() {
    let paginationControls = document.getElementById("pagination-controls");
    if (currentPage <= 1) {
        document.getElementById("prevPage").style.display = "none";
    } else {
        document.getElementById("prevPage").style.display = "inline-block";
    }
    document.getElementById("nextPage").style.display = "inline-block";
}

async function toggleOfflineMode() {
    let offlineMode = document.getElementById("offlineToggle").checked;
    await fetch("http://localhost:8080/news/offline", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ offline: offlineMode })
    });
    document.getElementById("offlineStatus").textContent = offlineMode ? "Offline Mode Enabled" : "Online Mode";
}
