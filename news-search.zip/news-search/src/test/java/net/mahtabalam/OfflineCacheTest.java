package net.mahtabalam;

import net.mahtabalam.model.NewsArticle;
import net.mahtabalam.util.OfflineCache;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class OfflineCacheTest {

    @Test
    void testCacheResultsAndGetCachedResults() {
        NewsArticle article1 = new NewsArticle("Title1", "http://example.com/1", "Source1");
        NewsArticle article2 = new NewsArticle("Title2", "http://example.com/2", "Source2");
        List<NewsArticle> articles = Arrays.asList(article1, article2);

        OfflineCache.cacheResults("test", articles);
        List<NewsArticle> cachedResults = OfflineCache.getCachedResults("test");

        assertEquals(articles, cachedResults);
    }

    @Test
    void testOfflineMode() {
        OfflineCache.setOfflineMode(true);
        assertTrue(OfflineCache.isOfflineMode());

        OfflineCache.setOfflineMode(false);
        assertFalse(OfflineCache.isOfflineMode());
    }
}