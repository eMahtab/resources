package net.mahtabalam;

import net.mahtabalam.model.NewsArticle;
import net.mahtabalam.service.NewsService;
import net.mahtabalam.util.OfflineCache;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

class NewsServiceTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private NewsService newsService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSearchNewsOnline() {
        NewsArticle article1 = new NewsArticle("Title1", "http://example.com/1", "The Guardian");
        NewsArticle article2 = new NewsArticle("Title2", "http://example.com/2", "New York Times");

        Map<String, Object> guardianResponse = Map.of("response", Map.of("results", Arrays.asList(
                Map.of("webTitle", "Title1", "webUrl", "http://example.com/1")
        )));
        Map<String, Object> nytResponse = Map.of("response", Map.of("docs", Arrays.asList(
                Map.of("abstract", "Title2", "web_url", "http://example.com/2")
        )));

        when(restTemplate.getForObject(anyString(), eq(Map.class))).thenReturn(guardianResponse, nytResponse);

        List<NewsArticle> results = newsService.searchNews("test", 1, 10);

        assertEquals(2, results.size());
        assertTrue(results.contains(article1));
        assertTrue(results.contains(article2));
    }

    @Test
    void testSearchNewsOffline() {
        OfflineCache.setOfflineMode(true);
        NewsArticle article1 = new NewsArticle("Title1", "http://example.com/1", "The Guardian");
        NewsArticle article2 = new NewsArticle("Title2", "http://example.com/2", "New York Times");
        List<NewsArticle> cachedArticles = Arrays.asList(article1, article2);

        OfflineCache.cacheResults("test", cachedArticles);

        List<NewsArticle> results = newsService.searchNews("test", 1, 10);

        assertEquals(2, results.size());
        assertTrue(results.contains(article1));
        assertTrue(results.contains(article2));
    }

    @Test
    void testPaginateResults() {
        NewsArticle article1 = new NewsArticle("Title1", "http://example.com/1", "Source1");
        NewsArticle article2 = new NewsArticle("Title2", "http://example.com/2", "Source2");
        NewsArticle article3 = new NewsArticle("Title3", "http://example.com/3", "Source3");

        List<NewsArticle> articles = Arrays.asList(article1, article2, article3);

        List<NewsArticle> page1 = newsService.paginateResults(articles, 1, 2);
        assertEquals(2, page1.size());
        assertTrue(page1.contains(article1));
        assertTrue(page1.contains(article2));

        List<NewsArticle> page2 = newsService.paginateResults(articles, 2, 2);
        assertEquals(1, page2.size());
        assertTrue(page2.contains(article3));
    }
}