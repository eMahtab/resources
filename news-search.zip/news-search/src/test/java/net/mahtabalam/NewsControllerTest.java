package net.mahtabalam;

import net.mahtabalam.controller.NewsController;
import net.mahtabalam.model.NewsArticle;
import net.mahtabalam.service.NewsService;
import net.mahtabalam.util.OfflineCache;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

class NewsControllerTest {

    @Mock
    private NewsService newsService;

    @InjectMocks
    private NewsController newsController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSearchNews() {
        NewsArticle article1 = new NewsArticle("Title1", "http://example.com/1", "Source1");
        NewsArticle article2 = new NewsArticle("Title2", "http://example.com/2", "Source2");
        List<NewsArticle> articles = Arrays.asList(article1, article2);

        when(newsService.searchNews("test", 1, 10)).thenReturn(articles);

        ResponseEntity<List<NewsArticle>> response = newsController.searchNews("test", 1, 10);

        assertEquals(2, response.getBody().size());
        assertTrue(response.getBody().contains(article1));
        assertTrue(response.getBody().contains(article2));
    }

    @Test
    void testToggleOffline() {
        ResponseEntity<String> response = newsController.toggleOffline(Map.of("offline", true));

        assertEquals("Offline mode set to: true", response.getBody());
        assertTrue(OfflineCache.isOfflineMode());

        response = newsController.toggleOffline(Map.of("offline", false));

        assertEquals("Offline mode set to: false", response.getBody());
        assertFalse(OfflineCache.isOfflineMode());
    }
}