package net.mahtabalam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
