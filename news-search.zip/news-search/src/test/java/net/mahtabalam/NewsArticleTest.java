package net.mahtabalam;

import net.mahtabalam.model.NewsArticle;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class NewsArticleTest {

    @Test
    void testEqualsAndHashCode() {
        NewsArticle article1 = new NewsArticle("Title1", "http://example.com/1", "Source1");
        NewsArticle article2 = new NewsArticle("Title1", "http://example.com/1", "Source2");
        NewsArticle article3 = new NewsArticle("Title2", "http://example.com/2", "Source1");

        assertEquals(article1, article2);
        assertNotEquals(article1, article3);

        assertEquals(article1.hashCode(), article2.hashCode());
        assertNotEquals(article1.hashCode(), article3.hashCode());
    }

    @Test
    void testGettersAndSetters() {
        NewsArticle article = new NewsArticle();
        article.setTitle("Title");
        article.setUrl("http://example.com");
        article.setSource("Source");

        assertEquals("Title", article.getTitle());
        assertEquals("http://example.com", article.getUrl());
        assertEquals("Source", article.getSource());
    }
}